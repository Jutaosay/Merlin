#!/bin/sh

# shadowsocks script for AM380 merlin firmware
# by sadog (sadoneli@gmail.com) from koolshare.cn

source /koolshare/scripts/base.sh
eval `dbus export ssconf_basic`

case "$ssconf_basic_test_domain" in
	https://www.google.com.hk/)
		speed_test_url="https://dl.google.com/drive-file-stream/GoogleDriveSetup.exe"
	;;
	https://www.facebook.com/)
		speed_test_url="https://scontent-sjc3-1.xx.fbcdn.net/m1/v/t6/An-Y531FBt1_Dmjmdml0fAxWVznPEZ4KhVulHN4RqyLIqKI4Fldv1Q2EBkOSRtG8co5l0O9EVtYm894u1-w.zip?ccb=10-5&oh=00_AT9wS67x0noZvrW6rZWkwT2CNg5Pvk3kmpL9AWsVR8wdvg&oe=62944A47&_nc_sid=857daf"
	;;
	*)
		speed_test_url="https://cdn.cloudflare.steamstatic.com/steam/apps/256843155/movie_max.mp4 "
	;;
esac

agent="User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:32.0) Gecko/20100101 Firefox/32.0"

speed_test_curl(){
	sleep 3
	local Byte=`curl -k -A "$agent" "$speed_test_url" -o /dev/null --socks5-hostname 127.0.0.1:23458 --connect-timeout 5 --max-time 12 2>&1 | tr '\r' '\n' | awk '{print $NF}' | sed '1,3d;$d' | awk 'function max(x){i=0;for(val in x){if(i<=x[val]){i=x[val];}}return i;} {if ($1 ~ /k/) {a[$1]=$1*1024;next} else if ($1 ~ /M/) {a[$1]=$1*1024*1024;next} else {a[$1]=$1;next}} END{print max(a) }'`
	sleep 1	
	local KB=`awk -v sum=$Byte -v n=1024 'BEGIN{printf "%0.2f\n", sum/n}'`
	local MB=`awk -v sum=$KB -v n=1024 'BEGIN{printf "%0.2f\n", sum/n}'`
	local Byte=${Byte%.*}
	local KB=${KB%.*}
	local result=`awk -v M=$MB -v k=$KB -v i=$Byte 'BEGIN { if(i>=1048576) print M"M"; else if(i<1024 && i>0) print i; else print k"K" }'`
	[ -z "$Byte" -o "$result" == "0K" ] && local result="failed"
	dbus set ssconf_basic_webtest_$nu=$result
}
# flush previous test value in the table
webtest=`dbus list ssconf_basic_webtest_ | sort -n -t "_" -k 4|cut -d "=" -f 1`
if [ ! -z "$webtest" ];then
	for line in $webtest
	do
		dbus remove "$line"
	done
fi

get_function_switch() {
	case "$1" in
		1)
			echo "true"
		;;
		*)
			echo "false"
		;;
	esac
}

get_ws_header() {
	if [ -n "$1" ];then
		echo {\"Host\": \"$1\"}
	else
		echo "null"
	fi
}

get_h2_host() {
	if [ -n "$1" ];then
		echo [\"$1\"]
	else
		echo "null"
	fi
}

get_path(){
	if [ -n "$1" ];then
		echo \"$1\"
	else
		echo "null"
	fi
}

get_fingerprint(){
	if [ -n "$1" ];then
		echo \"$1\"
	else
		echo "null"
	fi
}
get_tgfingerprint(){
	if [ -n "$1" ];then
		echo "$1"
	else
		echo "null"
	fi
}

create_v2ray_json(){

	rm -f /tmp/tmp_v2ray.json
	rm -f /tmp/tmp_user.json
	rm -f /tmp/tmp_v2ray.final.json

	# ============================
	# 新增：优先处理 v2ray_use_json=1 的节点
	# ============================
	local use_json=$(eval echo \$ssconf_basic_v2ray_use_json_$nu)
	if [ "$use_json" = "1" ]; then
		echo_date "webtest: 使用自定义 v2ray json 节点..."

		# 解码用户 json（系统里应该已有 base64_decode）
		local RAW_JSON=$(eval echo \$ssconf_basic_v2ray_json_$nu | base64_decode)
		echo "$RAW_JSON" > /tmp/tmp_user.json

		# 1) 统一 outbounds 为数组（兼容 outbound / outbounds）
		OUTBOUNDS_ARR=$(jq -c '
			if (.outbounds? // null) != null then
				.outbounds
			elif (.outbound? // null) != null then
				[ .outbound ]
			else
				[]
			end
		' /tmp/tmp_user.json)

		# 2) 判断是否是 xagg 聚合输入（tag 以 xagg_ 开头）
		IS_XAGG=$(echo "$OUTBOUNDS_ARR" | jq -r '
			any(.[]; ((.tag // "") | startswith("xagg_")))
		')

		# webtest 的基础模板：只保留原来的 socks inbound + log（最小改动）
		cat >"/tmp/tmp_v2ray.json" <<-EOF
			{
			  "log": {
			    "access": "/dev/null",
			    "error": "/tmp/v2ray_webtest_log.log",
			    "loglevel": "error"
			  },
			  "inbounds": [
			    {
			      "port": 23458,
			      "listen": "0.0.0.0",
			      "protocol": "socks",
			      "settings": {
			        "auth": "noauth",
			        "udp": false,
			        "ip": "127.0.0.1",
			        "clients": null
			      },
			      "streamSettings": null
			    }
			  ]
			}
		EOF

		if [ "$IS_XAGG" = "true" ]; then
			echo_date "webtest: 检测到 xagg 聚合节点，补全 routing / observatory..."

			# 3) 提取 tag 列表
			TAGS=$(echo "$OUTBOUNDS_ARR" | jq -c '[ .[] | .tag ]')

			# webtest 暂时固定策略（主页面才做 UI 动态）
			XAGG_STRATEGY="leastPing"

			# 4) 生成 routing + observatory
			ROBS=$(jq -nc --argjson tags "$TAGS" '
			{
			  "routing": {
			    "domainStrategy": "AsIs",
			    "balancers": [
			      {
			        "tag": "balancer-main",
			        "selector": $tags,
			        "strategy": { "type": "'"$XAGG_STRATEGY"'" }
			      }
			    ],
			    "rules": [
			      {
			        "type": "field",
			        "inboundTag": [],
			        "balancerTag": "balancer-main"
			      }
			    ]
			  },
			  "observatory": {
			    "subjectSelector": $tags,
			    "probeURL": "https://www.gstatic.com/generate_204",
			    "probeInterval": "30s"
			  }
			}
			')

			# 5) 合并写入最终配置
			jq \
				--argjson outbounds "$OUTBOUNDS_ARR" \
				--argjson robs "$ROBS" \
				'. + {outbounds: $outbounds} + $robs' \
				/tmp/tmp_v2ray.json > /tmp/tmp_v2ray.final.json
		else
			# 普通自定义 JSON（不启用聚合）
			jq \
				--argjson outbounds "$OUTBOUNDS_ARR" \
				'. + {outbounds: $outbounds}' \
				/tmp/tmp_v2ray.json > /tmp/tmp_v2ray.final.json
		fi

		mv /tmp/tmp_v2ray.final.json /tmp/tmp_v2ray.json
		return 0
	fi


		local kcp="null"
		local tcp="null"
		local ws="null"
		local h2="null"
		local grpc="null"
		local tls="null"
		local reality="null"
		local vless_flow=""

		# tcp和kcp下tlsSettings为null，ws和h2下tlsSettings
		[ "$(eval echo \$ssconf_basic_v2ray_network_security_$nu)" == "none" ] && local ssconf_basic_v2ray_network_security=""

		if [ "$(eval echo \$ssconf_basic_v2ray_network_$nu)" == "ws" -o "$(eval echo \$ssconf_basic_v2ray_network_$nu)" == "h2" ] && [ -z "$(eval echo \$ssconf_basic_v2ray_network_tlshost_$nu)" ] && [ -n "$(eval echo \$ssconf_basic_v2ray_network_host_$nu)" ]; then
		 	local ssconf_basic_v2ray_network_tlshost_$nu="$(eval echo \$ssconf_basic_v2ray_network_host_$nu)"
		fi

		local local_fingerprint=$(eval echo \$ssconf_basic_fingerprint_$nu)

		case "$(eval echo \$ssconf_basic_v2ray_network_security_$nu)" in
		tls)
			local tls="{
					\"allowInsecure\":  $(get_function_switch $(eval echo \$ssconf_basic_allowinsecure_$nu)),
					\"fingerprint\": $(get_fingerprint $local_fingerprint),
					\"serverName\": \"$(eval echo \$ssconf_basic_v2ray_network_tlshost_$nu)\"
					}"
					[ "$(eval echo \$ssconf_basic_v2ray_network_flow_$nu)" != "none" -a "$(eval echo \$ssconf_basic_v2ray_network_flow_$nu)" != "" ] && local vless_flow="\"flow\": \"$(eval echo \$ssconf_basic_v2ray_network_flow_$nu)\"," || local vless_flow=""
			;;
		reality)
			local reality="{
					\"serverName\": \"$(eval echo \$ssconf_basic_v2ray_network_tlshost_$nu)\",
					\"fingerprint\": $(get_fingerprint $local_fingerprint),
					\"publicKey\": \"$(eval echo \$ssconf_basic_xray_publicKey_$nu)\",
					\"shortId\": \"$(eval echo \$ssconf_basic_xray_shortId_$nu)\",
					\"spiderX\": \"\"
					}"
			local vless_flow="\"flow\": \"$(eval echo \$ssconf_basic_v2ray_network_flow_$nu)\","
			;;
		*)
			local tls="null"
			local reality="null"
			;;
		esac

		# incase multi-domain input
		if [ "$(eval echo \$ssconf_basic_v2ray_network_host_$nu | grep ",")" ]; then
			ssconf_basic_v2ray_network_host_$nu=$(eval echo \$ssconf_basic_v2ray_network_host_$nu | sed 's/,/", "/g')
		fi

		case "$(eval echo \$ssconf_basic_v2ray_network_$nu)" in
		tcp)
			if [ "$(eval echo \$ssconf_basic_v2ray_headtype_tcp_$nu)" == "http" ]; then
				local tcp="{
					\"connectionReuse\": true,
					\"header\": {
					\"type\": \"http\",
					\"request\": {
					\"version\": \"1.1\",
					\"method\": \"GET\",
					\"path\": [\"/\"],
					\"headers\": {
					\"Host\": [\"$(eval echo \$ssconf_basic_v2ray_network_host_$nu)\"],
					\"User-Agent\": [\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36\",\"Mozilla/5.0 (iPhone; CPU iPhone OS 10_0_2 like Mac OS X) AppleWebKit/601.1 (KHTML, like Gecko) CriOS/53.0.2785.109 Mobile/14A456 Safari/601.1.46\"],
					\"Accept-Encoding\": [\"gzip, deflate\"],
					\"Connection\": [\"keep-alive\"],
					\"Pragma\": \"no-cache\"
					}
					},
					\"response\": {
					\"version\": \"1.1\",
					\"status\": \"200\",
					\"reason\": \"OK\",
					\"headers\": {
					\"Content-Type\": [\"application/octet-stream\",\"video/mpeg\"],
					\"Transfer-Encoding\": [\"chunked\"],
					\"Connection\": [\"keep-alive\"],
					\"Pragma\": \"no-cache\"
					}
					}
					}
					}"
			else
				local tcp="null"
			fi
			;;
		kcp)
			local local_path=$(eval echo \$ssconf_basic_v2ray_network_path_$nu)
			local kcp="{
				\"mtu\": 1350,
				\"tti\": 50,
				\"uplinkCapacity\": 12,
				\"downlinkCapacity\": 100,
				\"congestion\": false,
				\"readBufferSize\": 2,
				\"writeBufferSize\": 2,
				\"seed\": \"$local_path\",
				\"header\": {
				\"type\": \"$(eval echo \$ssconf_basic_v2ray_headtype_kcp_$nu)\",
				\"request\": null,
				\"response\": null
				}
				}"
			[ -z "$local_path" ] && local kcp=$(echo $kcp | sed 's/"seed": "*, //')
			;;
		ws)
			local local_path=$(eval echo \$ssconf_basic_v2ray_network_path_$nu)
			local local_header=$(eval echo \$ssconf_basic_v2ray_network_host_$nu)
			local ws="{
				\"connectionReuse\": true,
				\"fingerprint\": $(get_fingerprint $local_fingerprint),
				\"path\": $(get_path $local_path),
				\"headers\": $(get_ws_header $local_header)
				}"
			;;
		h2)
			local local_path=$(eval echo \$ssconf_basic_v2ray_network_path_$nu)
			local local_header=$(eval echo \$ssconf_basic_v2ray_network_host_$nu)
			local h2="{
				\"fingerprint\": $(get_fingerprint $local_fingerprint),
				\"path\": $(get_path $local_path),
				\"host\": $(get_h2_host $local_header)
				}"
			;;
		grpc)
			local local_serviceName=$(eval echo \$ssconf_basic_v2ray_serviceName_$nu)
			local grpc="{
				\"multiMode\": true,
  				\"idle_timeout\": 13,
				\"fingerprint\": $(get_fingerprint $local_fingerprint),
				\"serviceName\": $(get_path $local_serviceName)
				}"
			;;
		esac

		# log area
		cat >"/tmp/tmp_v2ray.json" <<-EOF
			{
			"log": {
				"access": "/dev/null",
				"error": "/tmp/v2ray_webtest_log.log",
				"loglevel": "error"
			},
		EOF

		# inbounds area (23458 for socks5)
		cat >>"/tmp/tmp_v2ray.json" <<-EOF
				"inbounds": [
					{
						"port": 23458,
						"listen": "0.0.0.0",
						"protocol": "socks",
						"settings": {
							"auth": "noauth",
							"udp": false,
							"ip": "127.0.0.1",
							"clients": null
						},
						"streamSettings": null
					}
				],
		EOF

		# outbounds area
		if [ "$array13" == "vmess" ]; then
			cat >>"/tmp/tmp_v2ray.json" <<-EOF
				"outbounds": [
				  {
					"tag": "agentout",
					"protocol": "vmess",
					"settings": {
					  "vnext": [
						{
						  "address": "$(dbus get ssconf_basic_server_$nu)",
						  "port": $(eval echo \$ssconf_basic_port_$nu),
						  "users": [
							{
							  "id": "$(eval echo \$ssconf_basic_v2ray_uuid_$nu)",
							  "alterId": $(eval echo \$ssconf_basic_v2ray_alterid_$nu),
							  "security": "$(eval echo \$ssconf_basic_v2ray_security_$nu)"
							}
						  ]
						}
					  ],
					  "servers": null
					},
					"streamSettings": {
					  "network": "$(eval echo \$ssconf_basic_v2ray_network_$nu)",
					  "security": "$(eval echo \$ssconf_basic_v2ray_network_security_$nu)",
					  "tlsSettings": $tls,
					  "tcpSettings": $tcp,
					  "kcpSettings": $kcp,
					  "wsSettings": $ws,
					  "httpSettings": $h2,
					  "grpcSettings": $grpc
					},
					"mux": {
					  "enabled": $(get_function_switch $(eval echo \$ssconf_basic_v2ray_mux_enable_$nu)),
					  "concurrency": 8
					}
				  }
				]
				}
			EOF
		elif [ "$array13" == "vless" ]; then
			cat >>"/tmp/tmp_v2ray.json" <<-EOF
				"outbounds": [
				  {
					"tag": "agentout",
					"protocol": "vless",
					"settings": {
					  "vnext": [
						{
						  "address": "$(dbus get ssconf_basic_server_$nu)",
						  "port": $(eval echo \$ssconf_basic_port_$nu),
						  "users": [
							{
							  "id": "$(eval echo \$ssconf_basic_v2ray_uuid_$nu)",
							  "level": 1,
							  $vless_flow
							  "encryption": "none"
							}
						  ]
						}
					  ],
					  "servers": null
					},
					"streamSettings": {
					  "network": "$(eval echo \$ssconf_basic_v2ray_network_$nu)",
					  "security": "$(eval echo \$ssconf_basic_v2ray_network_security_$nu)",
					  "tlsSettings": $tls,
					  "realitySettings": $reality,
					  "tcpSettings": $tcp,
					  "kcpSettings": $kcp,
					  "wsSettings": $ws,
					  "httpSettings": $h2,
					  "grpcSettings": $grpc
					},
					"mux": {
					  "enabled": $(get_function_switch $(eval echo \$ssconf_basic_v2ray_mux_enable_$nu)),
					  "concurrency": 8
					}
				  }
				]
				}
			EOF
		fi
}

create_trojan_json(){
rm -f /tmp/tmp_v2ray.json

		 #trojan
		 # inbounds area (23458 for socks5)  
		cat > /tmp/tmp_v2ray.json <<-EOF
		{
			"log": {
				"access": "/dev/null",
				"error": "/tmp/v2ray_webtest_log.log",
				"loglevel": "error"
			},
				"inbounds": [
					{
						"port": 23458,
						"listen": "0.0.0.0",
						"protocol": "socks",
						"settings": {
							"auth": "noauth",
							"udp": false,
							"ip": "127.0.0.1",
							"clients": null
						},
						"streamSettings": null
					}
				],
			"outbounds": [
			  {
				"protocol": "trojan",
				"settings": {
				  "servers": [
					{
					  "address": "$array1",
					  "port": $array2,
					  "password": "$array3"
					}
				  ]
				},
				"streamSettings": {
				  "network": "tcp",
				  "security": "tls",
				  "tlsSettings": {
					"allowInsecure": $(get_function_switch $(eval echo \$ssconf_basic_allowinsecure_$nu)),  
                    "serverName": "$(eval echo \$ssconf_basic_trojan_sni_$nu)"
                }
				}
			  }
			]
		}
		EOF
}


create_trojango_json(){
	rm -f /tmp/tmp2_trojango.json
	if [ "$(eval echo \$ssconf_basic_trojan_network_$nu)" == "1" ]; then
		[ -n "$(eval echo \$ssconf_basic_v2ray_network_path_$nu)" ] && local ssconf_basic_v2ray_network_path=$(echo "/"$(eval echo \$ssconf_basic_v2ray_network_path_$nu)"" | sed 's,//,/,')
		[ -n "$(eval echo \$ssconf_basic_v2ray_network_host_$nu)" ] && local ssconf_basic_v2ray_network_host=$(eval echo \$ssconf_basic_v2ray_network_host_$nu)
		local ws="{ \"enabled\": true,
					\"path\":  \"$ssconf_basic_v2ray_network_path\",
					\"host\":  \"$ssconf_basic_v2ray_network_host\"
					}"
	else
		local ws="{ \"enabled\": false,
					\"path\":  \"\",
					\"host\":  \"\"
					}"
	fi
		local local_fingerprint=$(eval echo \$ssconf_basic_fingerprint_$nu)
		 #trojan go

		 #  23458 for socks5  
		cat >"/tmp/tmp2_trojango.json" <<-EOF
			{
				"run_type": "client",
				"local_addr": "127.0.0.1",
				"local_port": 23458,
				"remote_addr": "$array1",
				"remote_port": $array2,
				"log_level": 5,
				"log_file": "/tmp/trojan-go_webtest_log.log",
				"password": [
				"$array3"
				],
				"disable_http_check": false,
				"udp_timeout": 60,
				"ssl": {
					"verify": true,
					"verify_hostname": true,
					"sni": "$(eval echo \$ssconf_basic_trojan_sni_$nu)",
					"alpn": [
					"http/1.1"
					],
					"session_ticket": true,
					"reuse_session": true,
					"fingerprint": $(get_tgfingerprint $ss_basic_fingerprint)
				},
				"tcp": {
					"no_delay": true,
					"keep_alive": true,
					"prefer_ipv4": true
				},
				"mux": {
					"enabled": $(get_function_switch $(eval echo \$ssconf_basic_v2ray_mux_enable_$nu)),
					"concurrency": 8,
					"idle_timeout": 60
				},
				"websocket": $ws
				,
				"shadowsocks": {
					"enabled": false,
					"method": "AES-128-GCM",
					"password": ""
				}
			}
		EOF
	
}

create_naive_json(){
	rm -f /tmp/tmp2_naive.json
		 #NaiveProxy

		 #  23458 for socks
		cat >/tmp/tmp2_naive.json <<-EOF
			{
			"listen": "socks://127.0.0.1:23458",
			"proxy": "${array15}://${array16}:${array3}@${array1}:$array2"
			}
		EOF
}

create_hy2_json(){
	rm -f /tmp/tmp_hysteria.json 

		local hy2_obfs="$(eval echo \$ssconf_basic_hy2_obfs_$nu)"
	local hy2_up="$(eval echo \$ssconf_basic_hy2_up_mbps_$nu)"
	local hy2_down="$(eval echo \$ssconf_basic_hy2_down_mbps_$nu)"
	local hy2_obfs_block=""
	local hy2_bw_block=""

	if [ -n "$hy2_obfs" ]; then
		hy2_obfs_block=",
				"obfs": {
					"type": "salamander",
					"salamander": {
						"password": "$hy2_obfs"
					}
				}"
	fi

	if [ -n "$hy2_up" ] || [ -n "$hy2_down" ]; then
		[ -z "$hy2_up" ] && hy2_up="10"
		[ -z "$hy2_down" ] && hy2_down="50"
		hy2_bw_block=",
				"bandwidth": {
					"up": "${hy2_up} mbps",
					"down": "${hy2_down} mbps"
				}"
	fi

	cat >/tmp/tmp_hysteria.json <<-EOF
				{
				"server": "${array1}:${array2}",
				"auth": "${array3}",
				"tls": {
					"sni": "$(eval echo \$ssconf_basic_trojan_sni_$nu)",
					"insecure": $(get_function_switch $(eval echo \$ssconf_basic_allowinsecure_$nu))
				},
				"fastOpen": true,
				"lazy": true${hy2_obfs_block}${hy2_bw_block},
				"socks5": {
					"listen": "127.0.0.1:23458"
				}
			}
	EOF
}

create_ss2022_json(){
	rm -f /tmp/tmp_v2ray.json
		 #Shadowsocks 2022 
		 # inbounds area (23458 for socks5)  
		cat > /tmp/tmp_v2ray.json <<-EOF
		{
			"log": {
				"access": "/dev/null",
				"error": "/tmp/v2ray_webtest_log.log",
				"loglevel": "error"
			},
				"inbounds": [
					{
						"port": 23458,
						"listen": "0.0.0.0",
						"protocol": "socks",
						"settings": {
							"auth": "noauth",
							"udp": false,
							"ip": "127.0.0.1",
							"clients": null
						},
						"streamSettings": null
					}
				],
			"outbounds": [
			  {
				"protocol": "shadowsocks",
				"settings": {
				  "servers": [
					{
					  "address": "$array1",
					  "port": $array2,
					  "method": "$array4",
					  "password": "$array3"
					}
				  ]
				}
			  }
			]
		}
		EOF
}

start_webtest(){
	array1=`dbus get ssconf_basic_server_$nu`
	array2=`dbus get ssconf_basic_port_$nu`
	array3=`dbus get ssconf_basic_password_$nu|base64_decode`
	array4=`dbus get ssconf_basic_method_$nu`
	array5=`dbus get ssconf_basic_use_rss_$nu`
	array6=`dbus get ssconf_basic_rss_obfs_param_$nu`
	array7=`dbus get ssconf_basic_rss_protocol_$nu`
	array8=`dbus get ssconf_basic_rss_obfs_$nu`
	array9=`dbus get ssconf_basic_ss_v2ray_plugin_$nu`
	array10=`dbus get ssconf_basic_ss_v2ray_plugin_opts_$nu`
	array11=`dbus get ssconf_basic_mode_$nu`
	array12=`dbus get ssconf_basic_type_$nu`	
	array13=`dbus get ssconf_basic_v2ray_protocol_$nu`
	array14=`dbus get ssconf_basic_trojan_binary_$nu`
	array15=`dbus get ssconf_basic_naive_protocol_$nu`
	array16=`dbus get ssconf_basic_naive_user_$nu`
	array17=`dbus get ssconf_basic_v2ray_xray_$nu`

	if [ "$array12" == "0" ];then
		case $array4 in
			2022-blake3-aes-128-gcm|2022-blake3-aes-256-gcm|2022-blake3-chacha20-poly1305|none) SS2022_webtest="Y";;
			*)             SS2022_webtest="N";;
		esac
	fi
	[ "$SS2022_webtest" == "Y" ] && array12="3"

	[ "$array17" == "xray" ] && array17="xray run"

	if [ "$array10" != "" ];then
		if [ "$array9" == "1" ];then
			ARG_V2RAY_PLUGIN="--plugin v2ray-plugin --plugin-opts $array10"
		elif [ "$array9" == "2" ];then
			ARG_V2RAY_PLUGIN="--plugin obfs-local --plugin-opts $array10"
		else
			ARG_V2RAY_PLUGIN=""
		fi
	fi
	
	if [ "$array11" == "1" ] || [ "$array11" == "2" ] || [ "$array11" == "3" ] || [ "$array11" == "5" ];then
       # Resolve domain name to IP for SS and SSR
		if [ "$array12" == "1" ] || [ "$array12" == "0" ];then   
			IFIP=`echo $array1|grep -E "([0-9]{1,3}[\.]){3}[0-9]{1,3}|:"`
			if [ -z "$IFIP" ];then
				server_ip=`resolveip -4 -t 2 "$array1" |awk 'NR==1{print}'`
			fi 
		fi

		if [ "$array12" == "1" ];then   #ssr
			cat > /tmp/tmp_ss.json <<-EOF
			{
			    "server":"$server_ip",
			    "server_port":$array2,
			    "local_port":23458,
			    "password":"$array3",
			    "timeout":600,
			    "protocol":"$array7",
			    "obfs":"$array8",
			    "obfs_param":"$array6",
			    "method":"$array4"
			}
		EOF
			rss-local -b 0.0.0.0 -l 23458 -c /tmp/tmp_ss.json -f /var/run/sslocal2.pid >/dev/null 2>&1
			# result=`curl -o /dev/null -s -w %{time_connect}:%{time_starttransfer}:%{time_total}:%{speed_download} --socks5-hostname 127.0.0.1:23458 https://www.google.com/`
			speed_test_curl
			kill -9 `ps|grep -w rss-local|grep 23458|awk '{print $1}'` >/dev/null 2>&1
			rm -f /tmp/tmp_ss.json
			
		elif [ "$array12" == "0" ];then   #ss
			ss-local -b 0.0.0.0 -l 23458 -s $server_ip -p $array2 -k $array3 -m $array4 $ARG_V2RAY_PLUGIN -f /var/run/sslocal3.pid >/dev/null 2>&1
			speed_test_curl
			ss_local_pid=$(ps|grep -w ss-local|grep 23458|awk '{print $1}')			
			if [ -n "$ARG_V2RAY_PLUGIN" ];then 
				v2ray_plugin_pid=$(top -b -n 1 | grep -E 'v2ray-plugin|obfs-local' | awk -v ss_local_pid="$ss_local_pid"  '$2 == ss_local_pid {print $1}')
				kill -9 $v2ray_plugin_pid  >/dev/null 2>&1
			fi	
			kill -9 $ss_local_pid >/dev/null 2>&1

		elif [ "$array12" == "3" ] && [ "$SS2022_webtest" != "Y" ];then   #v2ray
			create_v2ray_json 
			$array17 -config=/tmp/tmp_v2ray.json >/dev/null 2>&1 &
			speed_test_curl
			kill -9 `ps|grep "$array17" |grep 'tmp_v2ray'|awk '{print $1}'` >/dev/null 2>&1	
			rm -f /tmp/tmp_v2ray.json /tmp/v2ray_webtest_log.log

		elif [ "$array12" == "3" ] && [ "$SS2022_webtest" == "Y" ];then   #ShadowSocks 2022
			create_ss2022_json 
			xray run -config=/tmp/tmp_v2ray.json >/dev/null 2>&1 &
			speed_test_curl
			kill -9 `ps|grep xray|grep 'tmp_v2ray'|awk '{print $1}'` >/dev/null 2>&1	
			rm -f /tmp/tmp_v2ray.json /tmp/v2ray_webtest_log.log
	
		elif [ "$array12" == "4" -a "$array14" == "Trojan" ];then   #trojan
			create_trojan_json 
			xray run -config=/tmp/tmp_v2ray.json >/dev/null 2>&1 &
			speed_test_curl
			kill -9 `ps|grep xray|grep 'tmp_v2ray'|awk '{print $1}'` >/dev/null 2>&1	
			rm -f /tmp/tmp_v2ray.json	/tmp/v2ray_webtest_log.log

		elif [ "$array12" == "4" -a "$array14" == "Trojan-Go" ];then   #trojan go
			create_trojango_json 
			trojan-go -config=/tmp/tmp2_trojango.json >/dev/null 2>&1 &
			speed_test_curl
			kill -9 `ps|grep 'trojan-go' | grep 'tmp2_trojango'|awk '{print $1}'` >/dev/null 2>&1
			rm -f /tmp/tmp_trojango.json /tmp/tmp2_trojango.json /tmp/trojan-go_webtest_log.log

		elif [ "$array12" == "4" -a "$array14" == "Hysteria2" ];then   #Hysteria2
			create_hy2_json 
			export QUIC_GO_DISABLE_ECN=true
			hysteria -c /tmp/tmp_hysteria.json -l error --disable-update-check  >/dev/null 2>&1 &
			speed_test_curl
			kill -9 `ps|grep hysteria|grep 'tmp_hysteria'|awk '{print $1}'` >/dev/null 2>&1	
			rm -f /tmp/tmp_hysteria.json
			
		elif [ "$array12" == "5" ];then   #naive
			create_naive_json 
			naive /tmp/tmp2_naive.json >/dev/null 2>&1 &
			speed_test_curl
			kill -9 `ps|grep 'naive' | grep 'tmp2_naive'|awk '{print $1}'` >/dev/null 2>&1
			rm -f  /tmp/tmp2_naive.json

		fi

	else
		dbus set ssconf_basic_webtest_$nu="failed"
	fi
}

# start testing
if [ "$ssconf_basic_test_node" != "0" ];then
	nu="$ssconf_basic_test_node"
	start_webtest
else
	server_nu=`dbus list ssconf_basic_server | sort -n -t "_" -k 4|cut -d "=" -f 1|cut -d "_" -f 4`
	for nu in $server_nu
	do
		start_webtest
	done
fi
